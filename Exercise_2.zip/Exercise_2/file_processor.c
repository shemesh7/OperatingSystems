#include <stdio.h>

#define MAX_DATA_FILE 256

// probably make functions for all edge cases

int main(int argc,char** argv[]) {
    FILE* data_file = argv[1];

    /**
     * check edge cases:
     * ✅ Reading beyond file size → Prevent it with boundary checks, and continue to the next line (dont exit).
     * ✅ Writing beyond file size → Same as reading, if I give you the offset of the end of the file it's ok (but after that it's not)
     *      so is offset 0 (but before that it's not).
     * ✅ Other things → You dont need to worry about integer overflow and `start > end` in the reading.
     * 
      **/
}